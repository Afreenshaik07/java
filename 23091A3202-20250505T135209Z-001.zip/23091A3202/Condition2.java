class Condition2
{
public static void main(String args[])
{
int n=12;
if(n>=0)
System.out.println("it is a positive number");
if(n%2==0)
System.out.println("even");
}
}