class A
{
static int a=10;
}
class static_variable
{
public static void main(String args[])
{
System.out.println("value of a is:"+A.a);
}
}
