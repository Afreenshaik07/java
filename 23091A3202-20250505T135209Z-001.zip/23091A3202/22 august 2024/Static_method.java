class A
{
static void show()
{
System.out.println("hello");
}
}
class static_method
{
public static void main(String args[])
{
A.show();
}
}
