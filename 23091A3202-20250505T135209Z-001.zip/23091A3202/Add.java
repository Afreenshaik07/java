class Add
{
public static void main(String args[])
{
int a=122,b=345,c,d,sum=0;
c=a%11;
d=b%400;
d=d/10;
sum=c+d;
System.out.println(sum);
}
}