import java.util.Scanner;
class Switch1
{
public static void main(String args[])
{
int n,count=0;
Scanner object=new Scanner(System.in);
System.out.print("1.factorial\n2.even or odd\n3.prime");
n=object.nextInt();
switch(n)
{
case 1:System.out.print("enter a number:");
int a=object.nextInt();
int fact=1,i;
for(i=1;i<=a;i++)
{
fact=fact*i;
}
System.out.println("factorial of a number:"+fact);
break;
case 2:System.out.print("enter a number:");
int b=object.nextInt();
if(b%2==0)
System.out.println("it is even");
else
System.out.println("it is odd");
break;
case 3: System.out.print("enter a number:");
int c=object.nextInt();
for(i=1;i<=c;i++)
{
if(c%i==0)
count=count+1;
}
if(count==2)
System.out.print("it is a  prime number");
else
System.out.print("it is not a prime number");
break;
default:
System.out.print("it is invalid choice");
}
}
}


