class Even
{
public static void main(String args[])
{
int n=Integer.parseInt(args[0]);
//for(int i=1;i<=n;i++)
if( n%2==0)
System.out.println(Even);
else
System.out.println(Odd);
}
}
