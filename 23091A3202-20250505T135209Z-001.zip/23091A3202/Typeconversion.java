class Escape
{
public static void main(String args[])
{
System.out.ptintln("CSEDS\n RGMCET");
System.out.ptintln("CSEDS\t RGMCET");
System.out.ptintln("CSEDS \\ RGMCET");
System.out.ptintln("CSEDS\'RGMCET");
System.out.ptintln("CSEDS\'RGMCET\'");
SySystem.out.ptintln("CSEDS\"RGMCET");
System.out.ptintln("CSEDS\"RGMCET\"");
System.out.ptintln("CSEDS\bRGMCET");
}
}