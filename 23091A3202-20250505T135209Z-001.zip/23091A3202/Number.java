import java.util.Scanner;
class Number
{
public static void main(String args[])
{
int n1;
Scanner object=new Scanner(System.in);
System.out.println("enter n1=");
n1=object.nextInt();
if(n1<0)
System.out.println("it is negative");
else if(n1>=0)
System.out.println("it is positive");
for(int i=1;i<=n1;i++)
{
if(n1%2==0)
System.out.println("even="+i);
else
System.out.println("Odd="+i);
}

 
//System.out.println("positive even number");
}
}
