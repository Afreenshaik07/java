public class Default
{
static boolean val1;
static double val2;
static float val3;
static int val4;
static long val5;
//static short val6;
//static char val7;
public static void main(String args[])
{
System.out.println("default values:..........");
System.out.ptintln("val1=",+val1);
System.out.ptintln("val2=",+val2);
System.out.ptintln("val3=",+val3);
System.out.ptintln("val4=",+val4);
System.out.ptintln("val5=",+val5);
System.out.ptintln("val6=",+val6);
System.out.ptintln("val7=",+val7);
}
}