import java.util.Scanner;
class Compute
{
int add(int a,int b)
{
return a+b;
}
int sub(int a,int b)
{
return a-b;
}
int mul(int a,int b)
{
return a*b;
}
int div(int a,int b)
{
return a/b;
}
int mdiv(int a,int b)
{
return a%b;
}
}
class Arthematic
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
Compute cc=new Compute();
System.out.print("enter the number1:");
int a=sc.nextInt();
System.out.print("enter the number2:");
int b=sc.nextInt();
System.out.println("Addition  of two numbers:",+cc.add(a,b));
System.out.println("Substraction  of two numbers:",+cc.sub(a,b));
System.out.println("Multiplication of two numbers:",+cc.mul(a,b));
System.out.println("Division  of two numbers:",+cc.div(a,b));
System.out.println("Modulus of two numbers:",+cc.mdiv(a,b));
}
}

