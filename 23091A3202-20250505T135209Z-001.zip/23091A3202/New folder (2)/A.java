class A
{
String name;
int roll_no;
void details()
{
System.out.println("details of"+name);
System.out.println(name+ "roll number:"+roll_no);
}
}
class Student_details
{
public static void main(String args[])
{
A ob=new A();
ob.name="Afreen";
ob.roll_no=123;
ob.details();
A ob1=ob;
ob1.name="Shaik";
ob1.roll_no=345;
ob1.details();
}
}
