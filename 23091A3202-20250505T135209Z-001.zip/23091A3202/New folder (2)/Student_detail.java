
class Student
{
Strng name;
int roll;
void show()
{
System.out.println("Student name is"+name);
System.out.println("Student roll number is ",+roll);
}
}
class Student_detail
{
public static void main(String args[])
{
Student s1=new Student();
s1.name="abc";
s1.roll=123;
s1.show()
}
}
