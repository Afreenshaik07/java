class Escape
{
public static void main(String args[])
{
System.out.println("CSEDS\n RGMCET");
System.out.println("CSEDS\t RGMCET");
System.out.println("CSEDS \\ RGMCET");
System.out.println("CSEDS\'RGMCET");
System.out.println("CSEDS\'RGMCET\'");
System.out.println("CSEDS\"RGMCET");
System.out.println("CSEDS\"RGMCET\"");
System.out.println("CSEDS\bRGMCET");
}
}