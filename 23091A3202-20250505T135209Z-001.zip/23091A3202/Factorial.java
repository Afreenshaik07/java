import java.util.Scanner;
class Factorial
{
public static void main(String args[])
{
int n,i,fact=1;
Scanner object=new Scanner(System.in);
System.out.println("Enter the value=");
n=object.nextInt();
for(i=1;i<=n;i++)
{
fact=fact*i;
}
System.out.println("Factorial="+fact);
}
}