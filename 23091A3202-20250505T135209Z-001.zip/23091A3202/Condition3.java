class Condition3
{
public static void main(String args[])
{
int n=34;
if(n>=0)
{
System.out.println("it is a positive number");
if(n%2==0)
{
System.out.print("it is even number");
}
else
{
System.out.println("it is odd number");
}
}
else
System.out.println("it is a negative number");
}
}