class Condition5
{
public static void main(String args[])
{
int age=20;
if(age>=18)
System.out.println("eligible for voting");
else
System.out.println("not eligible for voting");
}
}