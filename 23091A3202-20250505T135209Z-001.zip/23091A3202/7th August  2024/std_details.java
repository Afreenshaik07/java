class Student
{
Student (int a,int fact)
{
for(int i=1;i<=a;i++)
{
fact=fact*i;
}
System.out.println("the factorial of a number is:"+fact);
}
Student(int n)
{
if(n%2==0)
System.out.print("even");
else
System.out.println("odd");
}
}
class std_details
{
public static void main(String args[])
{
Student S1=new Student(6,1);
Student S2=new Student(7);
}
}