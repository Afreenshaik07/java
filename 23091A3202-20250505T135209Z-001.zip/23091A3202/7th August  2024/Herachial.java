class A
{
void fact()
{
int fact=1,n=5;
for(int i=1;i<=5;i++)
{
fact=fact*i;
}
System.out.println("the factorial of a number is:"+fact);
}
}
class B extends A
{
void even_odd()
{
int n=9;
if(n%2==0)
System.out.println("the given number is even");
else
System.out.println("the given number is odd");
}
}
class C extends A
{
void prime()
{
int count=0;
int n=7;
for(int i=1;i<=n;i++)
{
if(n%i==0)
count++;
}
if(count==2)
System.out.println("the given number is prime");
else
System.out.println("the given number is not prime");
}
}
class D extends A
{
void reverse()
{
int n=270,sum=0;
while(n>0)
{
int r=n%10;
sum=sum*10+r;
n=n/10;
}
System.out.print("the reserve of number is:"+sum);
}
}
class Herachial
{
public static void main(String args[])
{
B ob=new B();
ob.fact();
ob.even_odd();
C ob1=new C();
ob1.fact();
ob1.prime();
D ob2=new D();
ob2.fact();
ob2.reverse();
}
}

