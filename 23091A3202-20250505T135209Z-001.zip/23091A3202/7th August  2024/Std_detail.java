class Student
{
String name;
int roll;
Student()
{
name="abc";
roll=123;
System.out.println("Student name is"+name);
System.out.println("Student roll number is"+roll);
}
}
class Std_detail
{
public static void main(String args[])
{
Student s1=new Student();
}
}