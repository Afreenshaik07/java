class Palindrome
{
public static void main(String args[])
{
int n=12121,d,temp,rev=0;
temp=n;
while(n!=0)
{
d=n%10;
rev=rev*10+d;
n=n/10;
}
if(rev==temp)
System.out.println("it is palindrome");
else
System.out.println("it is not a palindrome");
}
}