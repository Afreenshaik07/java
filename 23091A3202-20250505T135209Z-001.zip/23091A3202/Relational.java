import java.util.Scanner;
class Relational
{
public static void main(String args[])
{
int n1=2,n2=1;
//Scanner object=new Scanner(System.in);
//System.out.print("enter number1:");
//n1=object.nextInt();
//System.out.print("enter number2:");
//n2=object.nextInt();
System.out.println("greater of two numbers:"+(n1>n2));
System.out.println("lessthan of two numbers:"+(n1<n2));
System.out.println("greaterthan or equal of two numbers:"+(n1>=n2));
System.out.println("lesserthan or equal of two numbers:"+(n1<=n2));
System.out.println("equal of two numbers:"+(n1==n2));
System.out.println("notequal of two numbers:"+(n1!=n2));

}
}


