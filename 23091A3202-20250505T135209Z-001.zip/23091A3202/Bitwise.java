import java.util.Scanner;
class Bitwise
{
public static void main(String args[])
{
int n1,n2;
Scanner object=new Scanner(System.in);
System.out.print("Enter number1");
n1=object.nextInt();
System.out.print("enter number2");
n2=object.nextInt();
System.out.println("bitwise AND on n1&n2:"+(n1&n2));
System.out.println("bitwise OR on n1/n2:"+(n1/n2));
System.out.println("Xor on on n1^n2:"+(n1^n2));
}
}
