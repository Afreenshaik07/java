class Ter
{
public static void main(String args[])
{
res=(n1<n2)?n2:n1);
System.out.ptint(res);
}
}