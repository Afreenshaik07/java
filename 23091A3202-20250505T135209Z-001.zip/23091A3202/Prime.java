import java.util.Scanner;
class Prime
{
public static void main(String args[])
{
Scanner object= new Scanner(System.in);
System.out.println("Enter value=");
int n=object.nextInt();
int i,count=0;
for(i=0;i<n;i++)
{
if(n%i==0)
count=count+i;
}
if(count==2)
System.out.println(i);
}
}


