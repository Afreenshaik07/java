class Condition4
{
public static void main(String args[])
{
int n=-45;
if(n>=0&&n%2==0)
System.out.print("even");
else
System.out.print("odd");
}
}