class cmd3
{
public static void main(String args[])
{
int n=Integer.parseInt(args[0]);
int fact=1,i;
for(i=1;i<=n;i++)
{
fact=fact*i;
}
System.out.println(fact);
}
}